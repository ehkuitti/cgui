import logo from './logo.svg';
import './App.css';
import Button from '@mui/material/Button';

function App() {
  return (
    <div className="App">
        <Button variant="contained" color="secondary" size="large">8</Button>
        <Button variant="contained" color="info" size="large">15</Button>
        <Button variant="contained" size="large" color="warning">Set</Button>  
    <div>

    

</div>
    </div>
  );
}

export default App;
